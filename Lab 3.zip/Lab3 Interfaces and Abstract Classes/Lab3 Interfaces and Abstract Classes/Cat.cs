﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Interfaces_and_Abstract_Classes
{
    public class Cat : Animal
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public short Age { get; set; }

        public Cat(string name, string colour, short age) : base(name, colour, age)
        {

        }

        public override void Eat()
        {
            Console.WriteLine("Cats eat mice");
        }
    }
}


