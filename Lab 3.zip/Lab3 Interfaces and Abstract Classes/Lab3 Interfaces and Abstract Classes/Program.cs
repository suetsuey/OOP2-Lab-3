﻿namespace Lab3_Interfaces_and_Abstract_Classes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a dog name: ");
            string dogName = Console.ReadLine();
            Console.WriteLine("Enter dog colour: ");
            string dogColour = Console.ReadLine();
            Console.WriteLine("Enter dog Age: ");
            short dogAge = short.Parse(Console.ReadLine());

            Dog dog = new Dog(dogName, dogColour, dogAge);
            dog.Eat();

            Console.WriteLine("Enter a cat name: ");
            string catName = Console.ReadLine();
            Console.WriteLine("Enter cat colour: ");
            string catColour = Console.ReadLine();
            Console.WriteLine("Enter cat Age: ");
            short catAge = short.Parse(Console.ReadLine());

            Cat cat = new Cat(catName, catColour, catAge);
            cat.Eat();

        }
    }
}