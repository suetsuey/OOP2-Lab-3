﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Interfaces_and_Abstract_Classes
{
    public class Dog : Animal
    {
        public string Name { get; set; }
        public string Colour { get; set; }
        public string Age { get; set; }

        public Dog(string name, string colour, short age) : base(name, colour, age)
        {

        }

    public override void Eat()
        {
            Console.WriteLine("Dogs eat meat.");
        }
    }
}
