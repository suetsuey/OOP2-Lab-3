﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_2
{
    public class Dog2 : IAnimal
    {
        private string name;
        private string colour;
        private double height;
        private short age;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Colour
        {
            get { return colour; }
            set { colour = value; }
        }

        public double Height
        {
            get { return height; }
            set { height = value; }
        }

        public short Age
        {
            get { return age; }
            set { age = value; }
        }

        public Dog2(string name, string colour, double height, short age)
        {
            this.name = name;
            this.colour = colour;
            this.height = height;
            this.age = age;
        }
        public void Eat()
        {
            Console.WriteLine("Dogs eat meat");
        }
        public void Cry()
        {
            Console.WriteLine("Woof!");
        }
    }
}
