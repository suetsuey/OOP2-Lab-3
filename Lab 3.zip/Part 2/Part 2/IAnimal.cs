﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part_2
{
    public interface IAnimal
    {
        abstract void Eat();

        string Cry()
        {
            return ("Cry..");
        }
    }
}
