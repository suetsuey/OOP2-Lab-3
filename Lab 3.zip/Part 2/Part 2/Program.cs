﻿namespace Part_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a dog name: ");
            string dogName = Console.ReadLine();
            Console.WriteLine("Enter dog colour: ");
            string dogColour = Console.ReadLine();
            Console.WriteLine("Enter dog height: ");
            double dogHeight = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter dog Age: ");
            short dogAge = short.Parse(Console.ReadLine());

            Dog2 dog = new Dog2(dogName, dogColour, dogHeight, dogAge);
            dog.Eat();
            dog.Cry();

            Console.WriteLine("Enter a cat name: ");
            string catName = Console.ReadLine();
            Console.WriteLine("Enter cat colour: ");
            string catColour = Console.ReadLine();
            Console.WriteLine("Enter cat height: ");
            double catHeight = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter cat Age: ");
            short catAge = short.Parse(Console.ReadLine());

            Cat2 cat = new Cat2(catName, catColour, catHeight, catAge);
            cat.Eat();
            cat.Cry();

            List<IAnimal> animalList = new List<IAnimal>();
            Dog2 dog1 = new Dog2("Golden", "Gold", 140, 5);
            Dog2 dog2 = new Dog2("Jobee", "Black", 87, 2);
            Cat2 cat1 = new Cat2("Jimmy", "Blue", 50, 7);
            Cat2 cat2 = new Cat2("Kitty", "White", 80, 4);
            animalList.Add(dog1);
            animalList.Add(dog2);
            animalList.Add(cat1);
            animalList.Add(cat2);
            animalList.Add(dog);
            animalList.Add(cat);
            Console.WriteLine("Animal list:");

            foreach (IAnimal animal in animalList)
            {
                if (animal is Dog2)
                {
                    Console.WriteLine($"Dog Name: {dog.Name}, Dog Colour: {dog.Colour}, Dog Height: {dog.Height}, Dog Age: {dog.Colour}");
                }
                else if (animal is Cat2)
                {
                    Console.WriteLine($"Cat Name: {cat.Name}, Cat Colour: {cat.Colour}, Cat Height: {cat.Height}, Cat Age: {cat.Colour}");
                }
            }
        }
    }
}